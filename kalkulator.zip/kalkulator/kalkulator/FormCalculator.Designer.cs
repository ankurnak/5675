﻿namespace kalkulator
{
    partial class FormCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.save_as_text = new System.Windows.Forms.Button();
            this.save_as_picture = new System.Windows.Forms.Button();
            this.review = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.brackets = new System.Windows.Forms.Button();
            this.percent = new System.Windows.Forms.Button();
            this.backspace = new System.Windows.Forms.Button();
            this.point = new System.Windows.Forms.Button();
            this.Clean_all = new System.Windows.Forms.Button();
            this.equality = new System.Windows.Forms.Button();
            this.division = new System.Windows.Forms.Button();
            this.Multiplication = new System.Windows.Forms.Button();
            this.Substraction = new System.Windows.Forms.Button();
            this.Addition = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cancel = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // save_as_text
            // 
            this.save_as_text.Location = new System.Drawing.Point(468, 337);
            this.save_as_text.Name = "save_as_text";
            this.save_as_text.Size = new System.Drawing.Size(94, 29);
            this.save_as_text.TabIndex = 82;
            this.save_as_text.Text = "зберегти як картинку";
            this.save_as_text.UseVisualStyleBackColor = true;
            this.save_as_text.Click += new System.EventHandler(this.save_as_text_Click);
            // 
            // save_as_picture
            // 
            this.save_as_picture.Location = new System.Drawing.Point(342, 337);
            this.save_as_picture.Name = "save_as_picture";
            this.save_as_picture.Size = new System.Drawing.Size(94, 29);
            this.save_as_picture.TabIndex = 81;
            this.save_as_picture.Text = "зберегти як картинку";
            this.save_as_picture.UseVisualStyleBackColor = true;
            this.save_as_picture.Click += new System.EventHandler(this.save_as_picture_Click);
            // 
            // review
            // 
            this.review.Location = new System.Drawing.Point(215, 337);
            this.review.Name = "review";
            this.review.Size = new System.Drawing.Size(94, 29);
            this.review.TabIndex = 80;
            this.review.Text = "переглянути збережене";
            this.review.UseVisualStyleBackColor = true;
            this.review.Click += new System.EventHandler(this.review_Click);
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(97, 337);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(94, 29);
            this.save.TabIndex = 79;
            this.save.Text = "зберегти";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // brackets
            // 
            this.brackets.Location = new System.Drawing.Point(215, 121);
            this.brackets.Name = "brackets";
            this.brackets.Size = new System.Drawing.Size(94, 29);
            this.brackets.TabIndex = 78;
            this.brackets.Text = "()";
            this.brackets.UseVisualStyleBackColor = true;
            this.brackets.Click += new System.EventHandler(this.brackets_Click);
            // 
            // percent
            // 
            this.percent.Location = new System.Drawing.Point(614, 283);
            this.percent.Name = "percent";
            this.percent.Size = new System.Drawing.Size(94, 29);
            this.percent.TabIndex = 77;
            this.percent.Text = "%";
            this.percent.UseVisualStyleBackColor = true;
            this.percent.Click += new System.EventHandler(this.percent_Click);
            // 
            // backspace
            // 
            this.backspace.Location = new System.Drawing.Point(614, 230);
            this.backspace.Name = "backspace";
            this.backspace.Size = new System.Drawing.Size(94, 29);
            this.backspace.TabIndex = 76;
            this.backspace.Text = "backspace";
            this.backspace.UseVisualStyleBackColor = true;
            this.backspace.Click += new System.EventHandler(this.backspace_Click);
            // 
            // point
            // 
            this.point.Location = new System.Drawing.Point(468, 121);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(94, 29);
            this.point.TabIndex = 75;
            this.point.Text = ".";
            this.point.UseVisualStyleBackColor = true;
            this.point.Click += new System.EventHandler(this.point_Click);
            // 
            // Clean_all
            // 
            this.Clean_all.Location = new System.Drawing.Point(614, 180);
            this.Clean_all.Name = "Clean_all";
            this.Clean_all.Size = new System.Drawing.Size(94, 29);
            this.Clean_all.TabIndex = 74;
            this.Clean_all.Text = "C";
            this.Clean_all.UseVisualStyleBackColor = true;
            this.Clean_all.Click += new System.EventHandler(this.Clean_all_Click);
            // 
            // equality
            // 
            this.equality.Location = new System.Drawing.Point(614, 121);
            this.equality.Name = "equality";
            this.equality.Size = new System.Drawing.Size(94, 29);
            this.equality.TabIndex = 73;
            this.equality.Text = "=";
            this.equality.UseVisualStyleBackColor = true;
            this.equality.Click += new System.EventHandler(this.equality_Click);
            // 
            // division
            // 
            this.division.Location = new System.Drawing.Point(97, 283);
            this.division.Name = "division";
            this.division.Size = new System.Drawing.Size(94, 29);
            this.division.TabIndex = 72;
            this.division.Text = "/";
            this.division.UseVisualStyleBackColor = true;
            this.division.Click += new System.EventHandler(this.division_Click);
            // 
            // Multiplication
            // 
            this.Multiplication.Location = new System.Drawing.Point(97, 230);
            this.Multiplication.Name = "Multiplication";
            this.Multiplication.Size = new System.Drawing.Size(94, 29);
            this.Multiplication.TabIndex = 71;
            this.Multiplication.Text = "*";
            this.Multiplication.UseVisualStyleBackColor = true;
            this.Multiplication.Click += new System.EventHandler(this.Multiplication_Click);
            // 
            // Substraction
            // 
            this.Substraction.Location = new System.Drawing.Point(97, 180);
            this.Substraction.Name = "Substraction";
            this.Substraction.Size = new System.Drawing.Size(94, 29);
            this.Substraction.TabIndex = 70;
            this.Substraction.Text = "-";
            this.Substraction.UseVisualStyleBackColor = true;
            this.Substraction.Click += new System.EventHandler(this.Substraction_Click);
            // 
            // Addition
            // 
            this.Addition.Location = new System.Drawing.Point(97, 121);
            this.Addition.Name = "Addition";
            this.Addition.Size = new System.Drawing.Size(94, 29);
            this.Addition.TabIndex = 69;
            this.Addition.Text = "+";
            this.Addition.UseVisualStyleBackColor = true;
            this.Addition.Click += new System.EventHandler(this.Addition_Click);
            // 
            // nine
            // 
            this.nine.Location = new System.Drawing.Point(468, 180);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(94, 29);
            this.nine.TabIndex = 68;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = true;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.Location = new System.Drawing.Point(342, 180);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(94, 29);
            this.eight.TabIndex = 67;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = true;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // seven
            // 
            this.seven.Location = new System.Drawing.Point(215, 180);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(94, 29);
            this.seven.TabIndex = 66;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = true;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // six
            // 
            this.six.Location = new System.Drawing.Point(468, 230);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(94, 29);
            this.six.TabIndex = 65;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = true;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // five
            // 
            this.five.Location = new System.Drawing.Point(342, 230);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(94, 29);
            this.five.TabIndex = 64;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.Location = new System.Drawing.Point(215, 230);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(94, 29);
            this.four.TabIndex = 63;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // three
            // 
            this.three.Location = new System.Drawing.Point(468, 283);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(94, 29);
            this.three.TabIndex = 62;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // two
            // 
            this.two.Location = new System.Drawing.Point(342, 283);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(94, 29);
            this.two.TabIndex = 61;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // one
            // 
            this.one.Location = new System.Drawing.Point(215, 283);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(94, 29);
            this.one.TabIndex = 60;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // zero
            // 
            this.zero.Location = new System.Drawing.Point(342, 121);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(94, 29);
            this.zero.TabIndex = 59;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = true;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(215, 84);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(351, 22);
            this.textBox1.TabIndex = 58;
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(614, 337);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(94, 29);
            this.cancel.TabIndex = 104;
            this.cancel.Text = "cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Location = new System.Drawing.Point(0, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(859, 63);
            this.panel1.TabIndex = 105;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Location = new System.Drawing.Point(0, 392);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(859, 63);
            this.panel2.TabIndex = 106;
            // 
            // FormCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 487);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.save_as_text);
            this.Controls.Add(this.save_as_picture);
            this.Controls.Add(this.review);
            this.Controls.Add(this.save);
            this.Controls.Add(this.brackets);
            this.Controls.Add(this.percent);
            this.Controls.Add(this.backspace);
            this.Controls.Add(this.point);
            this.Controls.Add(this.Clean_all);
            this.Controls.Add(this.equality);
            this.Controls.Add(this.division);
            this.Controls.Add(this.Multiplication);
            this.Controls.Add(this.Substraction);
            this.Controls.Add(this.Addition);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.six);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.three);
            this.Controls.Add(this.two);
            this.Controls.Add(this.one);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.textBox1);
            this.Name = "FormCalculator";
            this.Text = "FormCalculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button save_as_text;
        private System.Windows.Forms.Button save_as_picture;
        private System.Windows.Forms.Button review;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button brackets;
        private System.Windows.Forms.Button percent;
        private System.Windows.Forms.Button backspace;
        private System.Windows.Forms.Button point;
        private System.Windows.Forms.Button Clean_all;
        private System.Windows.Forms.Button equality;
        private System.Windows.Forms.Button division;
        private System.Windows.Forms.Button Multiplication;
        private System.Windows.Forms.Button Substraction;
        private System.Windows.Forms.Button Addition;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}